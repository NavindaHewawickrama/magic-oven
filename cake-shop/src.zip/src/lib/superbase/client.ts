import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "./database.types";

// Use this in Client Components ("use client" files).
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}