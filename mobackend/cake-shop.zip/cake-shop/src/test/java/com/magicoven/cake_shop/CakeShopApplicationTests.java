package com.magicoven.cake_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakeShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
